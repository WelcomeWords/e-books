package models

import "fmt"

// Usuario representa un usuario del sistema.
// Los campos comienzan con minúscula para hacerlos no exportados (privados)
// Se accede a ellos o se modifican a través de métodos públicos (Getters/Setters).
type Usuario struct {
	id     string
	nombre string
	correo string
	tipo   string // Ej: "Estudiante", "Profesor", "Administrador"
}

// NuevoUsuario es el "constructor" para crear una nueva instancia de Usuario.
// Se usa para inicializar un usuario con sus valores iniciales.
func NuevoUsuario(id, nombre, correo, tipo string) *Usuario {
	return &Usuario{
		id:     id,
		nombre: nombre,
		correo: correo,
		tipo:   tipo,
	}
}

// --- Métodos Getters (para obtener información de Usuario) ---

// GetID retorna el ID del usuario.
func (u *Usuario) GetID() string {
	return u.id
}

// GetNombre retorna el nombre del usuario.
func (u *Usuario) GetNombre() string {
	return u.nombre
}

// GetCorreo retorna el correo electrónico del usuario.
func (u *Usuario) GetCorreo() string {
	return u.correo
}

// GetTipo retorna el tipo de usuario (Estudiante, Profesor, Administrador).
func (u *Usuario) GetTipo() string {
	return u.tipo
}

// GetInfo retorna una cadena con la información completa del usuario.
func (u *Usuario) GetInfo() string {
	return fmt.Sprintf("ID: %s, Nombre: %s, Email: %s, Tipo: %s",
		u.id, u.nombre, u.correo, u.tipo)
}

// --- Métodos Setters (para modificar información de Usuario) ---

// SetNombre actualiza el nombre del usuario.
func (u *Usuario) SetNombre(nombre string) {
	u.nombre = nombre
}

// SetCorreo actualiza el correo electrónico del usuario.
func (u *Usuario) SetCorreo(correo string) {
	u.correo = correo
}

// SetTipo actualiza el tipo de usuario.
func (u *Usuario) SetTipo(tipo string) {
	u.tipo = tipo
}
