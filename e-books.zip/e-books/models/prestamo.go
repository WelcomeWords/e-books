package models

import (
	"fmt"
	"time"
)

// Prestamo representa un registro de préstamo de un libro a un usuario.
// Los campos comienzan con minúscula para hacerlos no exportados
// Se accede a ellos o se modifican a través de métodos publicos
type Prestamo struct {
	idPrestamo      string
	libroID         string
	usuarioID       string
	fechaPrestamo   time.Time
	fechaDevolucion *time.Time
	estado          string
}

// NuevoPrestamo es el "constructor" para crear una nueva instancia de Prestamo
func NuevoPrestamo(idPrestamo, libroID, usuarioID string) *Prestamo {
	return &Prestamo{
		idPrestamo:    idPrestamo,
		libroID:       libroID,
		usuarioID:     usuarioID,
		fechaPrestamo: time.Now(),
		estado:        "Activo",
	}
}

//  Metodos Getters sirve para obtener informacion de Prestamo

// GetIDPrestamo retorna el ID del prestamo
func (p *Prestamo) GetIDPrestamo() string {
	return p.idPrestamo
}

// GetLibroID retorna el ID del libro asociado al prestamo
func (p *Prestamo) GetLibroID() string {
	return p.libroID
}

// GetUsuarioID retorna el ID del usuario asociado al prestamo
func (p *Prestamo) GetUsuarioID() string {
	return p.usuarioID
}

// GetFechaPrestamo retorna la fecha y hora en que se realizo el prestamo
func (p *Prestamo) GetFechaPrestamo() time.Time {
	return p.fechaPrestamo
}

// GetFechaDevolucion retorna la fecha y hora de devolucion del libro
// Retorna un puntero a time.Time que puede ser nil si el libro aún no ha sido devuelto
func (p *Prestamo) GetFechaDevolucion() *time.Time {
	return p.fechaDevolucion
}

// GetEstado retorna el estado actual del prestamo
func (p *Prestamo) GetEstado() string {
	return p.estado
}

// GetInfo retorna una cadena con la informacion completa del prestamo
func (p *Prestamo) GetInfo() string {
	fechaDev := "N/A"
	if p.fechaDevolucion != nil {
		fechaDev = p.fechaDevolucion.Format("2006-01-02")
	}
	return fmt.Sprintf("ID Préstamo: %s, Libro ID: %s, Usuario ID: %s, Fecha Préstamo: %s, Devolución: %s, Estado: %s",
		p.idPrestamo, p.libroID, p.usuarioID, p.fechaPrestamo.Format("2006-01-02 15:04:05"), fechaDev, p.estado)
}

//  Metodos Setters/Acciones sirve para modificar el estado de Prestamo

// SetEstado actualiza el estado del prestamo
func (p *Prestamo) SetEstado(estado string) {
	p.estado = estado
}

// MarcarComoDevuelto actualiza la fecha de devolucion y el estado del prestamo a Completado
func (p *Prestamo) MarcarComoDevuelto() {
	now := time.Now()
	p.fechaDevolucion = &now // Asigna la fecha actual al puntero
	p.estado = "Completado"
}
