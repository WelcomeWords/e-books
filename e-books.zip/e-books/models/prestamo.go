package models

import (
	"fmt"
	"time"
)

// Prestamo representa un registro de préstamo de un libro a un usuario.
// Los campos comienzan con minúscula para hacerlos no exportados (privados).
// Se accede a ellos o se modifican a través de métodos públicos (Getters/Setters).
type Prestamo struct {
	idPrestamo      string
	libroID         string
	usuarioID       string
	fechaPrestamo   time.Time
	fechaDevolucion *time.Time // Puntero para permitir nil si no se ha devuelto
	estado          string     // Ej: "Activo", "Completado", "Vencido"
}

// NuevoPrestamo es el "constructor" para crear una nueva instancia de Prestamo.
func NuevoPrestamo(idPrestamo, libroID, usuarioID string) *Prestamo {
	return &Prestamo{
		idPrestamo:    idPrestamo,
		libroID:       libroID,
		usuarioID:     usuarioID,
		fechaPrestamo: time.Now(), // La fecha de préstamo es la actual
		estado:        "Activo",   // Por defecto, un nuevo préstamo está Activo
	}
}

// --- Métodos Getters (para obtener información de Prestamo) ---

// GetIDPrestamo retorna el ID del préstamo.
func (p *Prestamo) GetIDPrestamo() string {
	return p.idPrestamo
}

// GetLibroID retorna el ID del libro asociado al préstamo.
func (p *Prestamo) GetLibroID() string {
	return p.libroID
}

// GetUsuarioID retorna el ID del usuario asociado al préstamo.
func (p *Prestamo) GetUsuarioID() string {
	return p.usuarioID
}

// GetFechaPrestamo retorna la fecha y hora en que se realizo el préstamo
func (p *Prestamo) GetFechaPrestamo() time.Time {
	return p.fechaPrestamo
}

// GetFechaDevolucion retorna la fecha y hora de devolución del libro
// Retorna un puntero a time.Time, que puede ser nil si el libro aún no ha sido devuelto
func (p *Prestamo) GetFechaDevolucion() *time.Time {
	return p.fechaDevolucion
}

// GetEstado retorna el estado actual del prestamo (activo, completado, Vencido)
func (p *Prestamo) GetEstado() string {
	return p.estado
}

// GetInfo retorna una cadena con la informacion completa del prestamo
func (p *Prestamo) GetInfo() string {
	fechaDev := "N/A"
	if p.fechaDevolucion != nil {
		fechaDev = p.fechaDevolucion.Format("2006-01-02")
	}
	return fmt.Sprintf("ID Préstamo: %s, Libro ID: %s, Usuario ID: %s, Fecha Préstamo: %s, Devolución: %s, Estado: %s",
		p.idPrestamo, p.libroID, p.usuarioID, p.fechaPrestamo.Format("2006-01-02 15:04:05"), fechaDev, p.estado)
}

//  Metodos Setters/Acciones sirve para modificar el estado de Prestamo

// SetEstado actualiza el estado del préstamo.
func (p *Prestamo) SetEstado(estado string) {
	p.estado = estado
}

// MarcarComoDevuelto actualiza la fecha de devolucion y el estado del prestamo a Completado
func (p *Prestamo) MarcarComoDevuelto() {
	now := time.Now()
	p.fechaDevolucion = &now // Asigna la fecha actual al puntero
	p.estado = "Completado"
}
