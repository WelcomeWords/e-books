package models

import "fmt"

// Libro representa un libro en el sistema de gestion
// Los campos comienzan con minuscula para hacerlos no exportados
// Se accede a ellos o se modifican a traves de métodos publicos
type Libro struct {
	id         string
	titulo     string
	autor      string
	genero     string
	anio       int
	disponible bool
}

// NuevoLibro sirve para crear una nueva instancia de Libro
// Se usa para iniciar un libro con sus valores iniciales
func NuevoLibro(id, titulo, autor, genero string, anio int) *Libro {
	return &Libro{
		id:         id,
		titulo:     titulo,
		autor:      autor,
		genero:     genero,
		anio:       anio,
		disponible: true, // Por defecto, un libro nuevo esta disponible
	}
}

//  Metodos Getters sirve para obtener informacion de Libro

// GetID retorna el ID del libro
func (l *Libro) GetID() string {
	return l.id
}

// GetTitulo retorna el titulo del libro
func (l *Libro) GetTitulo() string {
	return l.titulo
}

// GetAutor retorna el autor del libro
func (l *Libro) GetAutor() string {
	return l.autor
}

// GetGenero retorna el genero del libro
func (l *Libro) GetGenero() string {
	return l.genero
}

// GetAnio retorna el año de publicacion del libro
func (l *Libro) GetAnio() int {
	return l.anio
}

// GetDisponible retorna el estado de disponibilidad del libro
func (l *Libro) GetDisponible() bool {
	return l.disponible
}

// GetInfo retorna una cadena con la informacion completa del libro
func (l *Libro) GetInfo() string {
	disponibilidad := "No"
	if l.disponible {
		disponibilidad = "Sí"
	}
	return fmt.Sprintf("ID: %s, Título: %s, Autor: %s, Género: %s, Año: %d, Disponible: %s",
		l.id, l.titulo, l.autor, l.genero, l.anio, disponibilidad)
}

//  Metodos Setters sirve para modificar informacion de Libro

// SetTitulo actualiza el título del libro
func (l *Libro) SetTitulo(titulo string) {
	l.titulo = titulo
}

// SetAutor actualiza el autor del libro
func (l *Libro) SetAutor(autor string) {
	l.autor = autor
}

// SetGenero actualiza el genero del libro
func (l *Libro) SetGenero(genero string) {
	l.genero = genero
}

// SetAnio actualiza el año de publicacion del libro
func (l *Libro) SetAnio(anio int) {
	l.anio = anio
}

// MarcarNoDisponible cambia el estado del libro a no disponible
func (l *Libro) MarcarNoDisponible() {
	l.disponible = false
}

// MarcarDisponible cambia el estado del libro a disponible
func (l *Libro) MarcarDisponible() {
	l.disponible = true
}
