package models

// Cualquier struct que tenga un método GetInfo() string implementará automáticamente esta interfaz.
type Informacion interface {
	GetInfo() string
}
