package main

import (
	"e-books/models" // Importamos el paquete models donde definimos nuestras structs
	"fmt"
	"sort"    // Importamos el paquete sort para ordenar slices
	"strings" // Importamos el paquete strings para manipulación de cadenas (ToLower, Contains)
)

// Declaración de slices globales para almacenar nuestros datos.
// Esto simula una "base de datos" en memoria para este avance.
var (
	libros    []models.Libro
	usuarios  []models.Usuario
	prestamos []models.Prestamo
)

// --- Funciones para Gestión de Libros ---

// RegistrarLibro añade un nuevo libro al slice de libros.
// Utiliza el constructor NuevoLibro del paquete models para crear la instancia.
func RegistrarLibro(id, titulo, autor, genero string, anio int) {
	nuevoLibro := models.NuevoLibro(id, titulo, autor, genero, anio)
	libros = append(libros, *nuevoLibro) // Añadimos la struct dereferenciada
	fmt.Printf("✔ Libro '%s' registrado exitosamente.\n", titulo)
}

// ListarLibros imprime la información de todos los libros registrados.
// Ahora utiliza el método GetInfo encapsulado para obtener la representación del libro.
func ListarLibros() {
	fmt.Println("\n--- Catálogo de Libros ---")
	if len(libros) == 0 {
		fmt.Println("No hay libros registrados en el sistema.")
		return
	}
	for _, libro := range libros {
		fmt.Println(libro.GetInfo()) // Usa el método GetInfo para obtener la información
	}
	fmt.Println("--------------------------")
}

// --- Funciones para Búsqueda de Libros ---

// BuscarLibroPorID busca y retorna un libro por su ID.
// Retorna un puntero al libro si lo encuentra, o nil si no existe.
func BuscarLibroPorID(id string) *models.Libro {
	for i := range libros {
		if libros[i].GetID() == id {
			return &libros[i] // Retorna un puntero al libro encontrado
		}
	}
	return nil // No se encontró el libro
}

// BuscarLibrosPorTitulo busca libros que contengan el título especificado (ignorando mayúsculas/minúsculas).
func BuscarLibrosPorTitulo(titulo string) []models.Libro {
	var resultados []models.Libro
	tituloLower := strings.ToLower(titulo) // Convertir a minúsculas para búsqueda insensible a mayúsculas
	for _, l := range libros {
		if strings.Contains(strings.ToLower(l.GetTitulo()), tituloLower) {
			resultados = append(resultados, l)
		}
	}
	return resultados
}

// BuscarLibrosPorAutor busca libros que contengan el nombre del autor especificado.
func BuscarLibrosPorAutor(autor string) []models.Libro {
	var resultados []models.Libro
	autorLower := strings.ToLower(autor)
	for _, l := range libros {
		if strings.Contains(strings.ToLower(l.GetAutor()), autorLower) {
			resultados = append(resultados, l)
		}
	}
	return resultados
}

// BuscarLibrosPorGenero busca libros que coincidan exactamente con el género especificado.
func BuscarLibrosPorGenero(genero string) []models.Libro {
	var resultados []models.Libro
	generoLower := strings.ToLower(genero)
	for _, l := range libros {
		if strings.ToLower(l.GetGenero()) == generoLower { // Coincidencia exacta de género
			resultados = append(resultados, l)
		}
	}
	return resultados
}

// BuscarLibrosPorAnio busca libros publicados en el año especificado.
func BuscarLibrosPorAnio(anio int) []models.Libro {
	var resultados []models.Libro
	for _, l := range libros {
		if l.GetAnio() == anio {
			resultados = append(resultados, l)
		}
	}
	return resultados
}

// BuscarLibrosConFiltros busca libros aplicando múltiples criterios de filtro.
// Los parámetros vacíos o cero son ignorados, permitiendo filtros opcionales.
// Los criterios de cadena de texto son insensibles a mayúsculas/minúsculas y buscan coincidencias parciales.
// El año busca una coincidencia exacta.
func BuscarLibrosConFiltros(titulo, autor, genero string, anio int) []models.Libro {
	resultados := libros // Empezamos con todos los libros y filtramos

	// Convertir a minúsculas para comparaciones insensibles a mayúsculas/minúsculas
	tituloLower := strings.ToLower(titulo)
	autorLower := strings.ToLower(autor)
	generoLower := strings.ToLower(genero)

	var librosFiltrados []models.Libro

	for _, libro := range resultados {
		// Asumimos que el libro cumple con los criterios inicialmente
		cumple := true

		// Filtrar por Título (si se proporciona)
		if titulo != "" && !strings.Contains(strings.ToLower(libro.GetTitulo()), tituloLower) {
			cumple = false
		}

		// Filtrar por Autor (si se proporciona y el libro aún cumple)
		if cumple && autor != "" && !strings.Contains(strings.ToLower(libro.GetAutor()), autorLower) {
			cumple = false
		}

		// Filtrar por Género (si se proporciona y el libro aún cumple)
		// Para género, se usa coincidencia exacta para "categorías"
		if cumple && genero != "" && strings.ToLower(libro.GetGenero()) != generoLower {
			cumple = false
		}

		// Filtrar por Año (si se proporciona y el libro aún cumple)
		if cumple && anio != 0 && libro.GetAnio() != anio {
			cumple = false
		}

		// Si el libro cumple con todos los criterios aplicables, añadirlo a los resultados
		if cumple {
			librosFiltrados = append(librosFiltrados, libro)
		}
	}
	return librosFiltrados
}

// --- Tipos Auxiliares para Ordenamiento de Libros ---
// Estos tipos implementan sort.Interface para permitir el ordenamiento de slices de Libro.

// ByTitulo implementa sort.Interface para ordenar libros por título (ascendente, ignorando mayúsculas/minúsculas)
type ByTitulo []models.Libro

func (a ByTitulo) Len() int      { return len(a) }
func (a ByTitulo) Swap(i, j int) { a[i], a[j] = a[j], a[i] }
func (a ByTitulo) Less(i, j int) bool {
	return strings.ToLower(a[i].GetTitulo()) < strings.ToLower(a[j].GetTitulo())
}

// ByAnio implementa sort.Interface para ordenar libros por año (ascendente)
type ByAnio []models.Libro

func (a ByAnio) Len() int           { return len(a) }
func (a ByAnio) Swap(i, j int)      { a[i], a[j] = a[j], a[i] }
func (a ByAnio) Less(i, j int) bool { return a[i].GetAnio() < a[j].GetAnio() }

// ByGenero implementa sort.Interface para ordenar libros por género (ascendente, ignorando mayúsculas/minúsculas)
type ByGenero []models.Libro

func (a ByGenero) Len() int      { return len(a) }
func (a ByGenero) Swap(i, j int) { a[i], a[j] = a[j], a[i] }
func (a ByGenero) Less(i, j int) bool {
	return strings.ToLower(a[i].GetGenero()) < strings.ToLower(a[j].GetGenero())
}

// --- Función para Ordenar Libros ---

// OrdenarLibros ordena una slice de libros por el criterio especificado.
// Criterios válidos: "titulo", "anio", "genero".
// Retorna la slice ordenada (la operación de ordenamiento se realiza in-place).
func OrdenarLibros(librosParaOrdenar []models.Libro, criterio string) []models.Libro {
	// Crear una copia de la slice para no modificar la original directamente en la demostración
	// Si necesitas modificar la slice original, puedes quitar esta línea y usar 'libros' directamente
	// pero para las demos es mejor trabajar sobre una copia temporal.
	ordenados := make([]models.Libro, len(librosParaOrdenar))
	copy(ordenados, librosParaOrdenar)

	switch strings.ToLower(criterio) {
	case "titulo":
		sort.Sort(ByTitulo(ordenados))
	case "anio":
		sort.Sort(ByAnio(ordenados))
	case "genero":
		sort.Sort(ByGenero(ordenados))
	default:
		fmt.Printf("❌ Criterio de ordenamiento inválido: '%s'. Opciones: 'titulo', 'anio', 'genero'.\n", criterio)
	}
	return ordenados // Retorna la slice ordenada
}

// --- Funciones para Gestión de Usuarios ---

// RegistrarUsuario añade un nuevo usuario al slice de usuarios.
// Utiliza el constructor NuevoUsuario del paquete models para crear la instancia.
func RegistrarUsuario(id, nombre, correo, tipo string) {
	nuevoUsuario := models.NuevoUsuario(id, nombre, correo, tipo)
	usuarios = append(usuarios, *nuevoUsuario) // Añadimos la struct dereferenciada
	fmt.Printf("✔ Usuario '%s' registrado exitosamente.\n", nombre)
}

// ListarUsuarios imprime la información de todos los usuarios registrados.
// Ahora utiliza el método GetInfo encapsulado para obtener la representación del usuario.
func ListarUsuarios() {
	fmt.Println("\n--- Lista de Usuarios ---")
	if len(usuarios) == 0 {
		fmt.Println("No hay usuarios registrados en el sistema.")
		return
	}
	for _, usuario := range usuarios {
		fmt.Println(usuario.GetInfo()) // Usa el método GetInfo para obtener la información
	}
	fmt.Println("-------------------------")
}

// --- Funciones para Gestión de Préstamos ---

// RealizarPrestamo crea un nuevo registro de préstamo.
// Busca el libro y el usuario por ID para asegurar que existan antes de crear el préstamo.
// Ahora devuelve un error si el libro o el usuario no se encuentran.
func RealizarPrestamo(idPrestamo, libroID, usuarioID string) error { // Agregamos "error" al retorno
	// Validación básica: buscar libro y usuario por ID
	libroEncontrado := false
	for _, l := range libros {
		if l.GetID() == libroID { // Usa GetID() para acceder al ID del libro
			libroEncontrado = true
			break
		}
	}
	if !libroEncontrado {
		// Retorna un error específico si el libro no se encuentra
		return fmt.Errorf("❌ Error: Libro con ID '%s' no encontrado para el préstamo.", libroID)
	}

	usuarioEncontrado := false
	for _, u := range usuarios {
		if u.GetID() == usuarioID { // Usa GetID() para acceder al ID del usuario
			usuarioEncontrado = true
			break
		}
	}
	if !usuarioEncontrado {
		// Retorna un error específico si el usuario no se encuentra
		return fmt.Errorf("❌ Error: Usuario con ID '%s' no encontrado para el préstamo.", usuarioID)
	}

	nuevoPrestamo := models.NuevoPrestamo(idPrestamo, libroID, usuarioID)
	prestamos = append(prestamos, *nuevoPrestamo)
	fmt.Printf("✔ Préstamo '%s' realizado exitosamente para el libro '%s' y usuario '%s'.\n",
		idPrestamo, libroID, usuarioID)
	return nil // Retorna nil (sin error) si el préstamo se realiza con éxito
}

// ListarPrestamos imprime la información de todos los préstamos registrados.
// Ahora utiliza el método GetInfo encapsulado para obtener la representación del préstamo.
func ListarPrestamos() {
	fmt.Println("\n--- Historial de Préstamos ---")
	if len(prestamos) == 0 {
		fmt.Println("No hay préstamos registrados en el sistema.")
		return
	}
	for _, prestamo := range prestamos {
		fmt.Println(prestamo.GetInfo()) // Usa el método GetInfo para obtener la información
	}
	fmt.Println("------------------------------")
}

// --- Función Principal (punto de entrada del programa) ---

func main() {
	// >>> CAMBIO SOLICITADO: Mensaje de inicio sin "Universidad" <<<
	fmt.Println("Iniciando Sistema de Gestión E-books...")

	// Demostración: Registrando algunos libros con IDs que empiezan con 'A', 'B', 'C'
	RegistrarLibro("A001", "Cien Años de Soledad", "Gabriel García Márquez", "Realismo Mágico", 1967)
	RegistrarLibro("B002", "1984", "George Orwell", "Distopía", 1949)
	RegistrarLibro("C003", "El Principito", "Antoine de Saint-Exupéry", "Fábula", 1943)

	ListarLibros()

	// Demostración: Registrando algunos usuarios con IDs que empiezan con 'D', 'E'
	RegistrarUsuario("D001", "Ana García", "ana.garcia@example.com", "Estudiante")
	RegistrarUsuario("E002", "Juan Pérez", "juan.perez@example.com", "Profesor")

	ListarUsuarios()

	// Demostración: Realizando algunos préstamos con IDs que empiezan con 'F', 'G'
	// Ahora, manejamos el error que devuelve RealizarPrestamo
	if err := RealizarPrestamo("F001", "A001", "D001"); err != nil { // Ana pide "Cien Años de Soledad"
		fmt.Println(err) // Imprime el error si lo hay
	}
	if err := RealizarPrestamo("G002", "B002", "E002"); err != nil { // Juan pide "1984"
		fmt.Println(err)
	}

	// Demostración de libro y usuario no encontrados con IDs 'H' y 'I'
	if err := RealizarPrestamo("H003", "H005", "D001"); err != nil { // Demostración de libro no encontrado (ID inventado)
		fmt.Println(err)
	}
	if err := RealizarPrestamo("I004", "A001", "I005"); err != nil { // Demostración de usuario no encontrado (ID inventado)
		fmt.Println(err)
	}

	ListarPrestamos()

	// Opcional: Marcar un préstamo como devuelto (demostración de método)
	if len(prestamos) > 0 {
		// Accediendo al ID del préstamo con el getter
		fmt.Printf("\nIntentando marcar préstamo '%s' como devuelto...\n", prestamos[0].GetIDPrestamo())
		prestamos[0].MarcarComoDevuelto()                                                    // Usamos el método de Prestamo
		fmt.Printf("✔ Préstamo '%s' marcado como devuelto.\n", prestamos[0].GetIDPrestamo()) // Usa el getter aquí también
		ListarPrestamos()
	}

	// --- Demostración de Búsqueda de Libros ---
	fmt.Println("\n--- Demostración de Búsqueda de Libros ---")

	// Búsqueda por ID
	fmt.Println("\nBuscando libro con ID 'A001':")
	if libroEncontrado := BuscarLibroPorID("A001"); libroEncontrado != nil {
		fmt.Println("✔ Libro encontrado:", libroEncontrado.GetInfo())
	} else {
		fmt.Println("❌ Libro no encontrado.")
	}
	fmt.Println("Buscando libro con ID 'Z999':")
	if libroEncontrado := BuscarLibroPorID("Z999"); libroEncontrado != nil {
		fmt.Println("✔ Libro encontrado:", libroEncontrado.GetInfo())
	} else {
		fmt.Println("❌ Libro no encontrado.")
	}

	// Búsqueda por Título
	fmt.Println("\nBuscando libros con 'princi' en el título:")
	resultadosTitulo := BuscarLibrosPorTitulo("princi")
	if len(resultadosTitulo) > 0 {
		for _, l := range resultadosTitulo {
			fmt.Println("✔ ", l.GetInfo())
		}
	} else {
		fmt.Println("❌ No se encontraron libros con ese título.")
	}

	// Búsqueda por Autor
	fmt.Println("\nBuscando libros de 'orwell':")
	resultadosAutor := BuscarLibrosPorAutor("orwell")
	if len(resultadosAutor) > 0 {
		for _, l := range resultadosAutor {
			fmt.Println("✔ ", l.GetInfo())
		}
	} else {
		fmt.Println("❌ No se encontraron libros de ese autor.")
	}

	// Búsqueda por Género
	fmt.Println("\nBuscando libros de género 'distopía':")
	resultadosGenero := BuscarLibrosPorGenero("Distopía")
	if len(resultadosGenero) > 0 {
		for _, l := range resultadosGenero {
			fmt.Println("✔ ", l.GetInfo())
		}
	} else {
		fmt.Println("❌ No se encontraron libros de ese género.")
	}

	// Búsqueda por Año
	fmt.Println("\nBuscando libros del año 1967:")
	resultadosAnio := BuscarLibrosPorAnio(1967)
	if len(resultadosAnio) > 0 {
		for _, l := range resultadosAnio {
			fmt.Println("✔ ", l.GetInfo())
		}
	} else {
		fmt.Println("❌ No se encontraron libros de ese año.")
	}

	// Búsqueda por Año (sin resultados)
	fmt.Println("\nBuscando libros del año 2020:")
	resultadosAnioSinResultados := BuscarLibrosPorAnio(2020)
	if len(resultadosAnioSinResultados) > 0 {
		for _, l := range resultadosAnioSinResultados {
			fmt.Println("✔ ", l.GetInfo())
		}
	} else {
		fmt.Println("❌ No se encontraron libros de ese año.")
	}

	// --- Demostración de Búsqueda de Libros con Filtros Múltiples ---
	fmt.Println("\n--- Demostración de Búsqueda de Libros con Filtros Múltiples ---")

	// Ejemplo 1: Buscar por Título y Género
	fmt.Println("\nBuscando libros con 'cien' en el título Y género 'Realismo Mágico':")
	resultadosMultifiltro1 := BuscarLibrosConFiltros("cien", "", "Realismo Mágico", 0)
	if len(resultadosMultifiltro1) > 0 {
		for _, l := range resultadosMultifiltro1 {
			fmt.Println("✔ ", l.GetInfo())
		}
	} else {
		fmt.Println("❌ No se encontraron libros con esos filtros.")
	}

	// Ejemplo 2: Buscar por Autor y Año
	fmt.Println("\nBuscando libros de 'george' Y del año 1949:")
	resultadosMultifiltro2 := BuscarLibrosConFiltros("", "george", "", 1949)
	if len(resultadosMultifiltro2) > 0 {
		for _, l := range resultadosMultifiltro2 {
			fmt.Println("✔ ", l.GetInfo())
		}
	} else {
		fmt.Println("❌ No se encontraron libros con esos filtros.")
	}

	// Ejemplo 3: Buscar con múltiples criterios que no coinciden
	fmt.Println("\nBuscando libros de 'orwell' Y género 'Fábula':")
	resultadosMultifiltro3 := BuscarLibrosConFiltros("", "orwell", "Fábula", 0)
	if len(resultadosMultifiltro3) > 0 {
		for _, l := range resultadosMultifiltro3 {
			fmt.Println("✔ ", l.GetInfo())
		}
	} else {
		fmt.Println("❌ No se encontraron libros con esos filtros.")
	}

	// Ejemplo 4: Solo por Autor (demostrando que los campos vacíos son ignorados)
	fmt.Println("\nBuscando libros solo por autor 'garcía':")
	resultadosMultifiltro4 := BuscarLibrosConFiltros("", "garcía", "", 0)
	if len(resultadosMultifiltro4) > 0 {
		for _, l := range resultadosMultifiltro4 {
			fmt.Println("✔ ", l.GetInfo())
		}
	} else {
		fmt.Println("❌ No se encontraron libros con esos filtros.")
	}

	// --- Demostración de Ordenamiento de Libros (NUEVO) ---
	fmt.Println("\n--- Demostración de Ordenamiento de Libros ---")

	// Para ordenar, podemos trabajar sobre una copia de los libros existentes
	// O, para una demostración más clara, un conjunto específico.
	// Vamos a usar una combinación para mostrar más variedad.
	librosParaOrdenarDemo := []models.Libro{
		*models.NuevoLibro("Z001", "Aventura en el Mar", "Capitán Ahab", "Aventura", 1851),
		*models.NuevoLibro("Y002", "El Gran Gatsby", "F. Scott Fitzgerald", "Clásico", 1925),
		*models.NuevoLibro("X003", "Zoológico de Papel", "Ken Liu", "Ciencia Ficción", 2011),
		*models.NuevoLibro("W004", "Crimen y Castigo", "Fyodor Dostoevsky", "Novela Psicológica", 1866),
	}
	// Añadimos algunos de los libros ya registrados para que estén en la mezcla también
	librosParaOrdenarDemo = append(librosParaOrdenarDemo, libros...)

	fmt.Println("\nLibros antes de ordenar:")
	for _, l := range librosParaOrdenarDemo {
		fmt.Println(l.GetInfo())
	}

	// Ordenar por Título
	fmt.Println("\nLibros ordenados por Título:")
	// Pasa una COPIA de los libros para ordenar, para que la slice original no se vea afectada por la demo
	librosOrdenadosPorTitulo := OrdenarLibros(librosParaOrdenarDemo, "titulo")
	for _, l := range librosOrdenadosPorTitulo {
		fmt.Println(l.GetInfo())
	}

	// Ordenar por Año
	fmt.Println("\nLibros ordenados por Año:")
	librosOrdenadosPorAnio := OrdenarLibros(librosParaOrdenarDemo, "anio")
	for _, l := range librosOrdenadosPorAnio {
		fmt.Println(l.GetInfo())
	}

	// Ordenar por Género
	fmt.Println("\nLibros ordenados por Género:")
	librosOrdenadosPorGenero := OrdenarLibros(librosParaOrdenarDemo, "genero")
	for _, l := range librosOrdenadosPorGenero {
		fmt.Println(l.GetInfo())
	}

	// Ordenar por criterio inválido
	fmt.Println("\nIntentando ordenar por criterio inválido 'abc':")
	OrdenarLibros(librosParaOrdenarDemo, "abc") // Esto imprimirá el mensaje de error

	fmt.Println("\nDemostración de avance finalizada.")
}
